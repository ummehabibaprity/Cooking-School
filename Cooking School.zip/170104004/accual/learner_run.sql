@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\fragment_site2.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\home_page_site2.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\menu_site2.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\Learner1_site2\learner_site2.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\Learner1_site2\view_learner.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\Learner1_site2\learner_site2.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\Learner1_site2\insertlearner_site2.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\Learner1_site2\view_learner.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\Learner1_site2\updatelearner_site2.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\Learner1_site2\view_learner.sql"



 
 
