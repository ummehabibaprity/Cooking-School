
set serveroutput on;
set verify off;
set linesize 300 ;
create or replace trigger updt
after update
on LEARNER_1
for each row
begin
	dbms_output.put_line('Update done');

end;
/
create or replace trigger dlt
after delete on
LEARNER_1
for each row
begin
	dbms_output.put_line('delete done');
end ;
/

delete from LEARNER_1 where LID=2;
delete from LEARNER_1 where LID=3;
delete from LEARNER_1 where LID=4;


accept X char prompt "Id: "
accept y char prompt "Name: "
accept z char prompt "Gender: "
accept a char prompt "Address: "
accept b number prompt "Phone no: "
accept c char prompt "Join date: "
accept d char prompt "Instructor name: "
accept e char prompt "Package name: "
accept f number prompt "Package cost: "


create or replace procedure update_learner2
IS
		
Lid LEARNER_1.LID%TYPE;
Name LEARNER_1.LNAME%TYPE;
Gender LEARNER_1.LGND%TYPE;
Address LEARNER_1.LADDRESS%TYPE;
Phn_No LEARNER_1.LPHN_NO%TYPE;
Join_Date LEARNER_1.LJOIN_DATE%TYPE;
Instructor LEARNER_1.LLEARNING_UNDER%TYPE;
Package_Name LEARNER_1.LPACKAGE_NAME%TYPE;
Cost LEARNER_1.LPACKAGE_COST%TYPE;

	
	
	
	
begin

Lid:=&x;
Name:='&y';
Gender:='&z';
Address:='&a';
Phn_No:=&b;
Join_Date:='&c';
Instructor:='&d';
Package_Name:='&e';
Cost:='&f';

	
DBMS_OUTPUT.PUT_LINE(Lid||' '||Name||' '||Gender||' '||Address||' '||Phn_No||' '||Join_Date||' '||Instructor||' '||Package_Name||' '||Cost);
update LEARNER_1 set LID=Lid,LNAME=Name,LGND=Gender,LADDRESS=Address,LPHN_NO=Phn_No,LJOIN_DATE=Join_Date,LLEARNING_UNDER=Instructor,LPACKAGE_NAME=Package_Name,LPACKAGE_COST=Cost;
commit;
		
	
	
	
	
	
			
end update_learner2;
/
declare

BEGIN
	update_learner2();
END;
/
