set serveroutput on;
set verify off;
set linesize 300 ;

create or replace trigger insrt
after insert on
LEARNER_1
for each row
begin
	dbms_output.put_line('insert done');
end ;
/


accept y char prompt "Name: "
accept z char prompt "Gender: "
accept a char prompt "Address: "
accept b number prompt "Phone no: "
accept c char prompt "Join date: "
accept d char prompt "Instructor name: "
accept e char prompt "Package name: "
accept f number prompt "Package cost: "


create or replace procedure insert_learner3
IS
		
Lid LEARNER_1.LID%TYPE;
Name LEARNER_1.LNAME%TYPE;
Gender LEARNER_1.LGND%TYPE;
Address LEARNER_1.LADDRESS%TYPE;
Phn_No LEARNER_1.LPHN_NO%TYPE;
Join_Date LEARNER_1.LJOIN_DATE%TYPE;
Instructor LEARNER_1.LLEARNING_UNDER%TYPE;
Package_Name LEARNER_1.LPACKAGE_NAME%TYPE;
Cost LEARNER_1.LPACKAGE_COST%TYPE;
n number;
	
	
	
	
begin
select count(LID)into n  from LEARNER_1;
Lid:=n+1;
Name:='&y';
Gender:='&z';
Address:='&a';
Phn_No:=&b;
Join_Date:='&c';
Instructor:='&d';
Package_Name:='&e';
Cost:='&f';
DBMS_OUTPUT.PUT_LINE(Lid||' '||Name||' '||Gender||' '||Address||' '||Phn_No||' '||Join_Date||' '||Instructor||' '||Package_Name||' '||Cost);	

insert into LEARNER_1 values(Lid,Name,Gender,Address,Phn_No,Join_Date,Instructor,Package_Name,Cost);
commit;
		
	
	
	
	
	
			
end insert_learner3;
/
declare

BEGIN
	insert_learner3();
END;
/
