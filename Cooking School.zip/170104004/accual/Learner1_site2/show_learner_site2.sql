clear screen;
set serveroutput on;
set verify off;
set linesize 300 ;



create or replace procedure show_learner
IS
		
Lid LEARNER_1.LID%TYPE;
Name LEARNER_1.LNAME%TYPE;
Gender LEARNER_1.LGND%TYPE;
Address LEARNER_1.LADDRESS%TYPE;
Phn_No LEARNER_1.LPHN_NO%TYPE;
Join_Date LEARNER_1.LJOIN_DATE%TYPE;
Instructor LEARNER_1.LLEARNING_UNDER%TYPE;
Package_Name LEARNER_1.LPACKAGE_NAME%TYPE;
	
begin

--DBMS_OUTPUT.PUT_LINE(Lid||' '||Name||' '||Gender||' '||Address||' '||Phn_No||' '||Join_Date||' '||Instructor||' '||Package_Name);	

select LID,LNAME,LGND,LADDRESS,LPHN_NO,LJOIN_DATE,LLEARNING_UNDER,LPACKAGE_NAME into Lid,Name,Gender,Address,Phn_No,Join_Date,Instructor,Package_Name from LEARNER_1;

DBMS_OUTPUT.PUT_LINE(Lid||' '||Name||' '||Gender||' '||Address||' '||Phn_No||' '||Join_Date||' '||Instructor||' '||Package_Name);	
	
			
end show_learner;
/

declare
begin 
	show_learner();
end;
/

select * from LEARNER_1;