
SET VERIFY OFF;
SET SERVEROUTPUT ON;
set linesize 300 ;


ACCEPT CHARACTER PROMPT "For value C ,you have three option : 1 for show ,2 for Insert , 3 for Delete , 4 for Update "

DECLARE
	input NUMBER;
	num LEARNER_1.LID%TYPE;
		
BEGIN
    
	
    input := '&c';
	IF input = 1 THEN
		dbms_output.put_line('You have select '||INPUT||'. Show Learner Database');
    ELSIF input = 2 THEN
		dbms_output.put_line('You have select '||INPUT||'. Insert into Learner Database');
		
		
	ELSIF INPUT=3 THEN
		
		dbms_output.put_line('You have select '||INPUT||'. Delete into Learner  Database');
		
		
		
    ELSIF INPUT=4 THEN
		dbms_output.put_line('You have select '||INPUT||'. Update into Learner  Database');
		
		
		
	ELSE
		raise no_data_found;
		
    END IF;
	
	exception

		
	when no_data_found then
		dbms_output.put_line('Sorry no option for this value');
	
END;

/
commit;
