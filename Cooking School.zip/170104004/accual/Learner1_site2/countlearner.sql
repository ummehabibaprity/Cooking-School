create or replace function countlearner(a in LEARNER_1.COST%TYPE;)
  return LEARNER_1.LID%TYPE;
  is
  n LEARNER_1.LID%TYPE:=0;

begin
	
	select count(LID) into n from LEARNER_1 where LEARNER_1.COST=a ;
	
	DBMS_OUTPUT.PUT_LINE('Total learner : ' ||n);
	
	return n;
commit;

end countlearner;
/
