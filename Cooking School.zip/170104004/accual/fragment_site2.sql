clear screen;
DROP TABLE ADMIN_1 CASCADE CONSTRAINTS;
DROP TABLE LEARNER_1 CASCADE CONSTRAINTS;
DROP TABLE COOK_1 CASCADE CONSTRAINTS;
DROP TABLE PACK_1 CASCADE CONSTRAINTS;
DROP TABLE PRITY_1 CASCADE CONSTRAINTS;

set linesize 300 ;

create table PRITY_1(
	ID NUMBER,
	INAME VARCHAR2(40)
);


create table ADMIN_1(
	ID NUMBER,
	PASSWORD VARCHAR2(30)
);
CREATE TABLE LEARNER_1
(
	LID NUMBER,
	LNAME varchar2(20) NOT NULL,
	LGND VARCHAR2(20),
	LADDRESS varchar2(20),
	LPHN_NO NUMBER(11),
	LJOIN_DATE varchar2(20),
	LLEARNING_UNDER varchar2(20),
	LPACKAGE_NAME varchar2(20),
	LPACKAGE_COST NUMBER(20),
	PRIMARY KEY(LID)
);
CREATE TABLE COOK_1
(
	CID NUMBER,
	CNAME varchar2(30),
	GENDER VARCHAR2(20),
	ADDRESS varchar2(30),
	PHN_NO NUMBER(11),
	RATTING VARCHAR2(30),
	SALARY NUMBER,
	CURRENT_STUDENT NUMBER,
	PRIMARY KEY(CID)
);
CREATE TABLE PACK_1
(
	PID NUMBER,
	PNAME VARCHAR2(30),
	PCOST NUMBER,
	CNAME VARCHAR2(30),
	PDURATION VARCHAR2(30),
	PRIMARY KEY (PID)
	--FOREIGN KEY (CNAME) REFERENCES COOK_1(CNAME)
);




--Insert data into ADMIN database

INSERT INTO ADMIN_1 VALUES(1,'Admin1');
INSERT INTO ADMIN_1 VALUES(2,'Admin2');

--Insert data into INSTRUMENT database

INSERT INTO PRITY_1 VALUES(1,'Sharp chefs knife');
INSERT INTO PRITY_1 VALUES(2,'Cutting boards');
INSERT INTO PRITY_1 VALUES(3,'Sheet pan');
INSERT INTO PRITY_1 VALUES(4,'8- to 12-inch frying pan');
INSERT INTO PRITY_1 VALUES(5,'Covered, oven-proof pot, about 6 quarts');
INSERT INTO PRITY_1 VALUES(6,'A whisk or a hand mixer');
INSERT INTO PRITY_1 VALUES(7,'Set of mixing bowls');
INSERT INTO PRITY_1 VALUES(8,'A spatula or flipper');
INSERT INTO PRITY_1 VALUES(9,'Measuring cups and spoons');
INSERT INTO PRITY_1 VALUES(10,'A wooden or silicone spoon for stirring');


--Insert data into  learner database
insert into LEARNER_1 values(1,'Prity','Female','Mirpur12','8944','01/01/21','Mr X','Traditional Food',2500);
insert into LEARNER_1 values(2,'Raisa','Female','Mirpur10','8955','01/02/21','Mr Y','ChineS Food ', 2800);
insert into LEARNER_1 values(3,'Habiba','Female','Mirpur14','8966','01/03/21','Mr Z','Italian Food ', 3000);

--Insert data into COOK database

INSERT INTO COOK_1 VALUES (1,'Mr x','FEMALE','Mirpur','8911','5 STAR',30000,25);
INSERT INTO COOK_1 VALUES (2,'Mr y','FEMALE','Kazipara','8922','5 STAR',32000,27);
INSERT INTO COOK_1 VALUES (3,'Mr z','MALE','Farmgate','8933','4 STAR',28000,20);


--Insert data into PACKAGE database

INSERT INTO PACK_1 VALUES (1,'Traditional Food',2500,'Mr x','2 month');
INSERT INTO PACK_1 VALUES (2,'Chines Food',3500,'Mr y','2 month');
INSERT INTO PACK_1 VALUES (3,'Italian Food',3800,'Mr Z','2 month');







COMMIT;

--SELECT * FROM ADMIN_1;
--SELECT * FROM LEARNER_1;
--SELECT * FROM COOK_1;
--SELECT * FROM PACK_1;

--SELECT * FROM PRITY_1;






