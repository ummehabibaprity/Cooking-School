
SET VERIFY OFF;
SET SERVEROUTPUT ON;
ACCEPT CHARACTER PROMPT "For value C ,you have three option : 1 for Learner , 2 for Cook , 3 for Package , 4 for Instrument"

DECLARE
	input NUMBER;
	
	
		
BEGIN
    
	
    input := '&c';
	
    IF input = 1 THEN
		dbms_output.put_line('You have select '||INPUT||'. Learner Database');
	
		
	ELSIF INPUT=2 THEN
		
		dbms_output.put_line('You have select '||INPUT||'. Cook Database');
		
		
    ELSIF INPUT=3 THEN
		dbms_output.put_line('You have select '||INPUT||'. Package Database');
		
	ELSIF INPUT=4 THEN
		dbms_output.put_line('You have select '||INPUT||'. Instrument Database');
		
	ELSE
		raise no_data_found;
	END IF;
		
	exception

		
	when no_data_found then
		dbms_output.put_line('Sorry no option for this value');
		
		
    
END;

/

