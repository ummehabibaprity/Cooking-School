
set serveroutput on;
set verify off;
set linesize 300 ;

create or replace trigger insrt_cook
after insert on
COOK_1
for each row
begin
	dbms_output.put_line('insert done');
end ;
/ 

accept y char prompt "Name: "
accept z char prompt "Gender: "
accept a char prompt "Address: "
accept b number prompt "Phone no: "
accept c char prompt "Ratting: "
accept d number prompt "Salary: "
accept e number prompt "Current Student: "



create or replace procedure insert_COOK
IS
		
Cid COOK_1.CID%TYPE;
CName COOK_1.CNAME%TYPE;
CGender COOK_1.GENDER%TYPE;
CAddress COOK_1.ADDRESS%TYPE;
CPhn_No COOK_1.PHN_NO%TYPE;
CRatting COOK_1.RATTING%TYPE;
CSalary COOK_1.SALARY%TYPE;
CCurrentstudent COOK_1.CURRENT_STUDENT%TYPE;

n number;
	
	
	
	
begin
select count(CID)into n  from COOK_1;
Cid:=n+1;
CName:='&y';
CGender:='&z';
CAddress:='&a';
CPhn_No:=&b;
CRatting:='&c';
CSalary:=&d;
CCurrentstudent:=&e;

DBMS_OUTPUT.PUT_LINE(Cid||' '||CName||' '||CGender||' '||CAddress||' '||CPhn_No||' '||CRatting||' '||CSalary||' '||CCurrentstudent);	

insert into COOK_1 values(Cid,CName,CGender,CAddress,CPhn_No,CRatting,CSalary,CCurrentstudent);
commit;
		
	
	
	
	
	
			
end insert_COOK;
/
declare

BEGIN
	insert_COOK();
END;
/
