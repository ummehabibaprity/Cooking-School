SET SERVEROUTPUT ON;
SET VERIFY OFF;

CREATE OR REPLACE PACKAGE mypack AS

	FUNCTION F1(A1 IN ADMIN_1.ID%TYPE,B1 IN ADMIN_1.PASSWORD%TYPE)
	RETURN NUMBER;
	
	PROCEDURE P1(B1 IN NUMBER);
END mypack;
/

CREATE OR REPLACE PACKAGE BODY mypack AS
	PROCEDURE P1(B1 IN NUMBER)
	IS
	
	BEGIN
	
		
		IF B1=1 THEN
			DBMS_OUTPUT.PUT_LINE('Welcome Admin');
		ELSIF B1=2 THEN
			DBMS_OUTPUT.PUT_LINE('Account not found. Please sign up.');		
	  
		END IF; 
		
	END P1;
	

	FUNCTION F1(A1 IN ADMIN_1.ID%TYPE,B1 IN ADMIN_1.PASSWORD%TYPE)
	RETURN NUMBER
	IS 
	C NUMBER;

	A ADMIN_1.ID%TYPE;
	B ADMIN_1.PASSWORD%TYPE;
	
	BEGIN
   	
		FOR R IN (SELECT * FROM ADMIN_1) LOOP  
			A := R.ID;
			B := R.PASSWORD;
						
			IF A=A1 and B=B1  THEN
				C := 1;
				EXIT;
			
			ELSE
				C := 2;
				EXIT;			 
			
			END IF;	
		  		
		END LOOP;
   	
		RETURN C;

	END F1;
	
	
	
END mypack;
/


ACCEPT X NUMBER PROMPT "ENTER ID = "
ACCEPT Y CHAR PROMPT "ENTER PASSWORD = "

DECLARE
    A ADMIN_1.ID%TYPE;
	B ADMIN_1.PASSWORD%TYPE;
	D NUMBER;
	PRITY EXCEPTION;
	
	

BEGIN
    A := &X;
	B := '&Y';
	D := mypack.F1(A,B);
	mypack.P1(D);
	IF A < 0 THEN
		RAISE PRITY;
	END IF;
	
	EXCEPTION
	
	WHEN PRITY THEN
		DBMS_OUTPUT.PUT_LINE('Cannot be -ve');
	WHEN  ACCESS_INTO_NULL	 THEN
       dbms_output.put_line('Access into null execption');
    WHEN  CASE_NOT_FOUND THEN
       dbms_output.put_line('Case not found exception');	
	WHEN INVALID_NUMBER THEN
        DBMS_OUTPUT.PUT_LINE('Invalid number exception');
	WHEN LOGIN_DENIED THEN
        DBMS_OUTPUT.PUT_LINE('Login denied');
	WHEN  OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('Exception other');

END;
/



