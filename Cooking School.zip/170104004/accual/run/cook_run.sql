
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\fragment_site2.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\menu_site2.sql"
 @"P:\Distributed Database System Lab(CSE4126)\170104004\accual\cook_menu.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\cook_view.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\cook_menu.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\insertcook_site.sql"
@"P:\Distributed Database System Lab(CSE4126)\170104004\accual\cook_view.sql"