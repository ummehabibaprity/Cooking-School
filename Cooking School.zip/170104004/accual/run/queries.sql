set linesize 500 ;
select * from LEARNER_1@site1;
select * from COOK_1@site1;
select * from PACK_1@site1;
select * from  PRITY_1@site1;


SELECT LID,LNAME FROM LEARNER_1@site1 WHERE LGND='Female';
SELECT LID,LNAME FROM LEARNER_1@site1 WHERE LGND='male';

select CID,CNAME from COOK_1@site1 where RATTING = '5 STAR';

select LPACKAGE_NAME ,sum(LPACKAGE_COST) as "total Earn"
from LEARNER_1@site1
group by LPACKAGE_NAME;

select LPACKAGE_NAME ,sum(LPACKAGE_COST) as "total Earn"
from LEARNER_1@site1
group by LPACKAGE_NAME
having sum(LPACKAGE_COST)>3000;

select distinct LPACKAGE_NAME ,max(LPACKAGE_COST) as "maximum Earn pack"
from LEARNER_1@site1
group by LPACKAGE_NAME
having sum(LPACKAGE_COST)>7000;

SELECT SUM(LPACKAGE_COST) AS "TOTAL Earn FROM LEARNER" FROM LEARNER_1@site1;
SELECT SUM(SALARY) AS "TOTAL PAID TO COOK" FROM COOK_1@site1;

--select SUM(LEARNER_1@site1.LPACKAGE_COST)-SUM(COOK_1@site1.SALARY) as [profit];


